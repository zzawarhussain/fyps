export const USER_ROLES = {
  ADMIN: "admin",
  USER: "user",
};

export const PAYMENT_METHODS = {
  CASH: "cash",
  CARD: "card",
};
